"Psi" <-
function(x, nstep=10, ...){
  UseMethod("Psi", x)
}

