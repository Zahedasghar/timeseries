"fevd" <-
function(x, n.ahead = 10, ...){
  UseMethod("fevd", x)
}
